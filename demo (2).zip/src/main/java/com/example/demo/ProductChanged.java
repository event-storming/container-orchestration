package com.example.demo;

import java.util.Date;

public class ProductChanged {
    String eventType;
    Long orderId;
    String productName;
    int productStock;

    public ProductChanged(){
        this.eventType = this.getClass().getSimpleName();
    }

    // get/set 메서드

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getProductStock() {
        return productStock;
    }

    public void setProductStock(int productStock) {
        this.productStock = productStock;
    }
}